import base64
import re
import sys
from Crypto.Cipher import Blowfish
from Crypto.Util.Padding import unpad

def ssh_injector(file_path: str, key: bytes = b'263386285977449155626236830061505221752'):
    try:
        with open(file_path, 'rb') as file:
            text = base64.b64decode(file.read())
            iv = b'\x00\x01\x02\x03\x04\x05\x06\x07'
            cipher = Blowfish.new(key, Blowfish.MODE_CBC, iv)
            plaintext = cipher.decrypt(text)
            decrypted_text = unpad(plaintext, Blowfish.block_size).decode()
            print("┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n")
            pattern = r'<entry key="(.*)">(.*)</entry>'
            matches = re.findall(pattern, decrypted_text)
            for match in matches:
                key, value = match
                print(f"[#] [{key}] : {value}")
            print("━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━")  # Added print statement
    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    if len(sys.argv) != 2: 
        sys.exit(1)
    
    file_name = sys.argv[1]
    ssh_injector(file_name)