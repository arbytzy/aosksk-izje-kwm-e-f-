import json 
import sys
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
from base64 import b64decode

def decrypt_aes_ecb_128(ciphertext, key):
    cipher = AES.new(key, AES.MODE_ECB)
    decrypted_text = cipher.decrypt(ciphertext)
    return unpad(decrypted_text, AES.block_size)

def format_decrypted_string(decrypted_string):
    formatted_string = ""
    data = json.loads(decrypted_string)
    for key, value in data.items():
        if isinstance(value, dict):
            formatted_string += f"[#] [{key}]:\n"
            for inner_key, inner_value in value.items():
                formatted_string += f"[#] [{inner_key}]: {inner_value}\n"
        elif isinstance(value, list):
            for item in value:
                formatted_string += f"[#] [{key}]:\n"
                for inner_key, inner_value in item.items():
                    formatted_string += f"[#] [{inner_key}]: {inner_value}\n"
        else:
            formatted_string += f"[#] [{key}]: {value}\n"
    return formatted_string

def handle_security_error(message, error):
    print(message)
    print(error)

def nm(file_path):
    key = b64decode("X25ldHN5bmFfbmV0bW9kXw==")
    decrypted_results = "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"

    try:
        with open(file_path, 'rb') as file:
            encrypted_contents_list = file.readlines()

        for encrypted_contents in encrypted_contents_list:
            try:
                decrypted_string = decrypt_aes_ecb_128(b64decode(encrypted_contents), key).decode()
                formatted_string = format_decrypted_string(decrypted_string)
                decrypted_results += formatted_string + ""
            except Exception as e:
                handle_security_error("Error during decryption. Please check the key and file", e)
    except FileNotFoundError:
        print("File not found.")
        
    decrypted_results += "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
    return decrypted_results

if __name__ == "__main__":
    # Cek apakah argumen file path disediakan
    if len(sys.argv) != 2:
        sys.exit(1)

    # Ambil file path dari argumen baris perintah
    file_path = sys.argv[1]

    # Sekarang Anda dapat menggunakan file_path dalam kode Anda, misalnya:
    decrypted_text = nm(file_path)
    print(decrypted_text)