import base64
import os
import time
import json
import sys
import zlib
import requests
import asyncio

from urllib.parse import quote_plus, urlparse

from bs4 import BeautifulSoup

result_list = []

class BicoLink: 
    def __init__(self): 
        self.session = requests.Session()
        self.ad_url = "https://bicolink.com"
        # self.api_key = "a8e7ea11d56c8f753de55a7c383410fe28a7fef1" #punya gw
        # self.api_key = "7b2fe5403500d03a3eee0f366c5ce75e7f50442e" #punya om enzo
        #BICO TEST
        self.api_key = "a173eec03c1d83181195dc9243a89628b1fd8609"

    async def generate_links(self, target) -> str: 
        def get_payload(content, name) -> str: 
            input_el = content.select_one(f"input[name='{name}']")
            return input_el.get("value")
        
        global result_list
        headers, params, payload = dict(), dict(), dict()

        full_url = os.path.join(self.ad_url, "st")

        headers["user-agent"] = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"

        params["api"] = self.api_key
        params["url"] = target

        res_payloads = self.session.get(full_url, headers=headers.copy(), params=params.copy())
        
        if res_payloads.status_code == 200: 
            content = BeautifulSoup(res_payloads.content, "html.parser")

            payload["_method"] = "POST"
            payload["_csrfToken"] = get_payload(content, "_csrfToken")
            payload["api"] = self.api_key
            payload["url"] = target
            payload["_Token[fields]"] = get_payload(content, "_Token[fields]")
            payload["_Token[unlocked]"] = get_payload(content, "_Token[unlocked]")
        
        res_link = self.session.post(full_url, params=params, headers=headers, data=payload )
        # print(res_link)
        if res_link.status_code == 200: 
            bicolink_url = urlparse(res_link.history[1].url)
            bicolink_url = bicolink_url._replace(netloc="go.bicolink.net")
            result_list.append(bicolink_url.geturl())
            return bicolink_url.geturl()

async def main(): 
    loop = asyncio.get_event_loop()
    
    bicolink = BicoLink()
    for _ in range(5): 
        loop.create_task(bicolink.generate_links(target="http://x101.vercel.app/" + str(_)))
    
    while True: 
        print(result_list)
        await asyncio.sleep(2)

if __name__ == "__main__": 
    asyncio.run(main())