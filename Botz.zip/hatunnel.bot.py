
#build321
import zlib
import base64
import json
import hashlib
from pathlib import Path
from urllib.parse import parse_qsl, quote_plus, unquote_plus
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
from telebot.async_telebot import AsyncTeleBot
from handler import BicoLink
from Crypto.Cipher import Blowfish
import subprocess
import os
import re
import tempfile
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Hash import SHA256
from base64 import b64decode, b64encode
import logging

logging.basicConfig(level=logging.DEBUG)
#tok = "7115188703:AAEe4UkXQ_i47w4jdA2iyQutZnSgI32diiI"
tok = "7489370032:AAGgbvMBUXFMDonz3MUEp4cC-JvzJGhvz7g"
if tok is None:
    logging.error("Bot token is None")
else:
    logging.debug(f"Bot token: {tok}")
bot = AsyncTeleBot(tok)


#[KEYS]
mina = "QW5kcm9pZFY="
mina_password = base64.b64decode(mina).decode('utf-8')
xscks = "MTEwMTAxIDExMDEwMCAxMDExMDAgMTEwMTAxIDExMDAwMSAxMDExMDAgMTEwMTAxIDExMDEwMCAxMDExMDAgMTEwMTAxIDExMDExMCAxMDExMDAgMTEwMTAxIDExMDEwMCAxMDExMDAgMTEwMTAwIDExMTAwMSAxMDExMDAgMTEwMTAxIDExMDEwMCAxMDExMDAgMTEwMTAxIDExMDAxMCAxMDExMDAgMTEwMTAxIDExMDEwMCAxMDExMDAgMTEwMTAxIDExMDAxMCAxMDExMDAgMTEwMTAxIDExMDEwMCAxMDExMDAgMTEwMTAxIDExMDAxMSAxMDExMDAgMTEwMTAxIDExMDEwMSAxMDExMDAgMTEwMTAxIDExMDEwMCAxMDExMDAgMTEwMTAxIDExMDEwMSAxMDExMDAgMTEwMTEwIDExMDEwMSAxMDExMDAgMTEwMTAxIDExMDAwMCAxMDExMDAgMTEwMTAwIDExMTAwMCAxMDExMDAgMTEwMDExIDExMDAxMCAxMDExMDAgMTAwMDAwIA=="
xscks_password = base64.b64decode(xscks).decode('utf-8')
ziv_password = "fubvx788b46v"
tnl_password = "B1m93p$$9pZcL9yBs0b$jJwtPM5VG@Vg"
pcx_password = "cinbdf665$4"
pb_password = "Cw1G6s0K8fJVKZmhSLZLw3L1R3ncNJ2e"
phc_password = "fubvx788b46v"
fnnetwork_password = "Ed"
mrc_password = "Ed"
mij_password = "Ed"
hbd_password = "Ed"
hdb_password = "Ed"
mtl_password = "Ed"
uwu_password = "Ed"
sksrv_password = "6pq8YieK$8D2kT4a6Pizv3i56nWi"

ipt = "QEFkZWRheW8ncyBXZVR1bm5lbA=="
ipt_password = base64.b64decode(ipt).decode('utf-8')
#algoritma rez ipt sama
def decrypt(ciphertext, password):
    if len(ciphertext) == 0:
        return ""
    v = str_to_longs(base64.b64decode(ciphertext))
    k = str_to_longs(password[:16].encode('utf-8'))
    n = len(v)
    z = v[n - 1]
    y = v[0]
    delta = -0x658C6C4C
    mx = 0
    q = 6 + 52 // n
    sum = q * delta

    while sum != 0:
        e = (sum >> 2) & 3
        for p in range(n - 1, -1, -1):
            z = v[p - 1] if p > 0 else v[n - 1]
            mx = (z >> 5 ^ (y << 2)) + (y >> 3 ^ (z << 4)) ^ (sum ^ y) + (k[p & 3 ^ e] ^ z)
            y = (v[p] - mx) & 0xffffffff
            v[p] = y
        sum -= delta

    plaintext = longs_to_str(v)
    plaintext = plaintext.rstrip('\x00')

    return plaintext

def str_to_longs(data):
    l = []
    for i in range(0, len(data), 4):
        a = data[i] if i < len(data) else 0
        b = (data[i + 1] << 8) if i + 1 < len(data) else 0
        c = (data[i + 2] << 16) if i + 2 < len(data) else 0
        d = (data[i + 3] << 24) if i + 3 < len(data) else 0
        l.append(a + b + c + d)
    return l

def longs_to_str(l):
    s = ''
    for num in l:
        s += chr(num & 0xFF)
        s += chr((num >> 8) & 0xFF)
        s += chr((num >> 16) & 0xFF)
        s += chr((num >> 24) & 0xFF)
    return s
    
# Fungsi untuk mendekripsi file .ipt
def decrypt_ipt_file(file_content, password):
    try:
        decrypted_text = decrypt(file_content, password)
        return decrypted_text
    except Exception as e:
        return f"Error: {e}"
#ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss
class AESCrypt:
    AES_MODE = AES.MODE_CBC
    AES_BLOCK_SIZE = 16
    HASH_ALGORITHM = 'SHA-256'
    IV = b'\x00' * AES_BLOCK_SIZE

    @staticmethod
    def generate_key(password):
        hashed_key = hashlib.sha256(password.encode()).digest()
        return hashed_key

    @staticmethod
    def pad_message(message):
        padding_length = AESCrypt.AES_BLOCK_SIZE - (len(message) % AESCrypt.AES_BLOCK_SIZE)
        padded_message = message + bytes([padding_length] * padding_length)
        return padded_message

    @staticmethod
    def unpad_message(padded_message):
        padding_length = padded_message[-1]
        return padded_message[:-padding_length]

    @staticmethod
    def decrypt(password, encoded_ciphertext):
        key = AESCrypt.generate_key(password)
        cipher = AES.new(key, AES.MODE_CBC, AESCrypt.IV)
        ciphertext = base64.b64decode(encoded_ciphertext)
        decrypted_message = cipher.decrypt(ciphertext)
        unpadded_message = AESCrypt.unpad_message(decrypted_message)
        return unpadded_message.decode()

# Fungsi untuk mendekripsi file .mina 
def decrypt_mina_file(file_content, password):
    try:
        decrypted_text = AESCrypt.decrypt(password, file_content)
        cleaned_data = decrypted_text.replace('\n', '').replace('\r', '').replace('\t', '')
        # Load JSON data
        json_data = json.loads(cleaned_data)

        # Extract keys and values
        filtered_data = {f"[#] [{key}]": f": {value}" for key, value in json_data.items()}

        # Format and return the result
        formatted_result = "\n".join([f"{key.strip(',')}{value}" for key, value in filtered_data.items()])
        formatted_result = "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n" + formatted_result + "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
        return formatted_result
    except Exception as e:
        return f"Error: {e}"

def decrypt_xscks_file(file_content, password):
    try:
        decrypted_text = AESCrypt.decrypt(password, file_content)
        cleaned_data = decrypted_text.replace('\n', '').replace('\r', '').replace('\t', '')
        # Load JSON data
        json_data = json.loads(cleaned_data)

        # Extract keys and values
        filtered_data = {f"[#] [{key}]": f": {value}" for key, value in json_data.items()}

        # Format and return the result
        formatted_result = "\n".join([f"{key.strip(',')}{value}" for key, value in filtered_data.items()])
        formatted_result = "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n" + formatted_result + "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
        return formatted_result
    except Exception as e:
        return f"Error: {e}"   


#ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss
#Tnl

def decrypt_tnl_file(encrypted_tnl, password):
    try:
        # Memastikan bahwa input adalah objek byte
        if isinstance(encrypted_tnl, str):
            encrypted_tnl = encrypted_tnl.encode('utf-8')

        # Memisahkan konten terenkripsi menjadi bagian-bagian yang sesuai
        split_base64_contents = encrypted_tnl.split(b'.')
        split_contents = list(map(base64.b64decode, split_base64_contents))
        
        # Membangun kunci dekripsi menggunakan PBKDF2
        decryption_key = PBKDF2(password.encode('utf-8'), split_contents[0], hmac_hash_module=SHA256)
        
        # Membuat objek cipher AES dengan mode GCM dan nonce yang sesuai
        cipher = AES.new(decryption_key, AES.MODE_GCM, nonce=split_contents[1])
        
        # Melakukan dekripsi dan verifikasi
        decrypted_contents = cipher.decrypt_and_verify(split_contents[2][:-16], split_contents[2][-16:])
        
        # Mengembalikan hasil dekripsi dalam format teks UTF-8
        return decrypted_contents.decode('utf-8', 'ignore')
    except ValueError as e:
        print("Error decrypting file:", str(e))
        return None
    except Exception as e:
        print("Unexpected error:", str(e))
        return None

# Fungsi filter untuk konten tnl
def filter_tnl_content(contents):
    try:
        filtered_contents = "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
        lines = contents.split('\n')
        for line in lines:
            if line.strip().startswith("<entry"):
                key_value = line.strip().replace("<entry key=\"", "").replace("</entry>", "").replace('"/>', '').split("\">")
                if len(key_value) > 1:
                    key, value = key_value
                    filtered_contents += f"[#] [{key}]: {value}\n"
                else:
                    key = key_value[0]
                    filtered_contents += f"[#] [{key}]: ***\n"
        filtered_contents += "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
        return filtered_contents
    except Exception as e:
        return f"Error: {e}"
        
#ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss
#pcx
def decrypt_pcx_file(encrypted_pcx, password):
    try:
        # Memastikan bahwa input adalah objek byte
        if isinstance(encrypted_pcx, str):
            encrypted_pcx = encrypted_pcx.encode('utf-8')

        # Memisahkan konten terenkripsi menjadi bagian-bagian yang sesuai
        split_base64_contents = encrypted_pcx.split(b'.')
        split_contents = list(map(base64.b64decode, split_base64_contents))
        
        # Membangun kunci dekripsi menggunakan PBKDF2
        decryption_key = PBKDF2(password.encode('utf-8'), split_contents[0], hmac_hash_module=SHA256)
        
        # Membuat objek cipher AES dengan mode GCM dan nonce yang sesuai
        cipher = AES.new(decryption_key, AES.MODE_GCM, nonce=split_contents[1])
        
        # Melakukan dekripsi dan verifikasi
        decrypted_contents = cipher.decrypt_and_verify(split_contents[2][:-16], split_contents[2][-16:])
        
        # Mengembalikan hasil dekripsi dalam format teks UTF-8
        return decrypted_contents.decode('utf-8', 'ignore')
    except ValueError as e:
        print("Error decrypting file:", str(e))
        return None
    except Exception as e:
        print("Unexpected error:", str(e))
        return None
        
        
# Fungsi filter untuk konten pcx
def filter_pcx_content(contents):
    try:
        filtered_contents = "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
        lines = contents.split('\n')
        for line in lines:
            if line.strip().startswith("<entry"):
                key_value = line.strip().replace("<entry key=\"", "").replace("</entry>", "").replace('"/>', '').split("\">")
                if len(key_value) > 1:
                    key, value = key_value
                    filtered_contents += f"[#] [{key}]: {value}\n"
                else:
                    key = key_value[0]
                    filtered_contents += f"[#] [{key}]: ***\n"
        filtered_contents += "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
        return filtered_contents
    except Exception as e:
        return f"Error: {e}"
        

#ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss
#pb
def decrypt_pb_file(encrypted_pb, password):
    try:
        # Memastikan bahwa input adalah objek byte
        if isinstance(encrypted_pb, str):
            encrypted_pb = encrypted_pb.encode('utf-8')

        # Memisahkan konten terenkripsi menjadi bagian-bagian yang sesuai
        split_base64_contents = encrypted_pb.split(b'.')
        split_contents = list(map(base64.b64decode, split_base64_contents))
        
        # Membangun kunci dekripsi menggunakan PBKDF2
        decryption_key = PBKDF2(password.encode('utf-8'), split_contents[0], hmac_hash_module=SHA256)
        
        # Membuat objek cipher AES dengan mode GCM dan nonce yang sesuai
        cipher = AES.new(decryption_key, AES.MODE_GCM, nonce=split_contents[1])
        
        # Melakukan dekripsi dan verifikasi
        decrypted_contents = cipher.decrypt_and_verify(split_contents[2][:-16], split_contents[2][-16:])
        
        # Mengembalikan hasil dekripsi dalam format teks UTF-8
        return decrypted_contents.decode('utf-8', 'ignore')
    except ValueError as e:
        print("Error decrypting file:", str(e))
        return None
    except Exception as e:
        print("Unexpected error:", str(e))
        return None
        
        
# Fungsi filter untuk konten pb
def filter_pb_content(contents):
    try:
        filtered_contents = "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
        lines = contents.split('\n')
        for line in lines:
            if line.strip().startswith("<entry"):
                key_value = line.strip().replace("<entry key=\"", "").replace("</entry>", "").replace('"/>', '').split("\">")
                if len(key_value) > 1:
                    key, value = key_value
                    filtered_contents += f"[#] [{key}]: {value}\n"
                else:
                    key = key_value[0]
                    filtered_contents += f"[#] [{key}]: ***\n"
        filtered_contents += "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━\n"
        return filtered_contents
    except Exception as e:
        return f"Error: {e}"

#ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss
#phc
def decrypt_phc_file(encrypted_phc, password):
    try:
        # Memastikan bahwa input adalah objek byte
        if isinstance(encrypted_phc, str):
            encrypted_phc = encrypted_phc.encode('utf-8')

        # Memisahkan konten terenkripsi menjadi bagian-bagian yang sesuai
        split_base64_contents = encrypted_phc.split(b'.')
        split_contents = list(map(base64.b64decode, split_base64_contents))
        
        # Membangun kunci dekripsi menggunakan PBKDF2
        decryption_key = PBKDF2(password.encode('utf-8'), split_contents[0], hmac_hash_module=SHA256)
        
        # Membuat objek cipher AES dengan mode GCM dan nonce yang sesuai
        cipher = AES.new(decryption_key, AES.MODE_GCM, nonce=split_contents[1])
        
        # Melakukan dekripsi dan verifikasi
        decrypted_contents = cipher.decrypt_and_verify(split_contents[2][:-16], split_contents[2][-16:])
        
        # Mengembalikan hasil dekripsi dalam format teks UTF-8
        return decrypted_contents.decode('utf-8', 'ignore')
    except ValueError as e:
        print("Error decrypting file:", str(e))
        return None
    except Exception as e:
        print("Unexpected error:", str(e))
        return None
        
        
# Fungsi filter untuk konten phc
def filter_phc_content(contents):
    try:
        filtered_contents = "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
        lines = contents.split('\n')
        for line in lines:
            if line.strip().startswith("<entry"):
                key_value = line.strip().replace("<entry key=\"", "").replace("</entry>", "").replace('"/>', '').split("\">")
                if len(key_value) > 1:
                    key, value = key_value
                    filtered_contents += f"[#] [{key}]: {value}\n"
                else:
                    key = key_value[0]
                    filtered_contents += f"[#] [{key}]: ***\n"
        filtered_contents += "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
        return filtered_contents
    except Exception as e:
        return f"Error: {e}"
        
#ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss
        
def decrypt_mrc_file(encrypted_mrc, password):
    try:
        # Memastikan bahwa input adalah objek byte
        if isinstance(encrypted_mrc, str):
            encrypted_mrc = encrypted_mrc.encode('utf-8')

        # Memisahkan konten terenkripsi menjadi bagian-bagian yang sesuai
        split_base64_contents = encrypted_mrc.split(b'.')
        split_contents = list(map(base64.b64decode, split_base64_contents))
        
        # Membangun kunci dekripsi menggunakan PBKDF2
        decryption_key = PBKDF2(password.encode('utf-8'), split_contents[0], hmac_hash_module=SHA256)
        
        # Membuat objek cipher AES dengan mode GCM dan nonce yang sesuai
        cipher = AES.new(decryption_key, AES.MODE_GCM, nonce=split_contents[1])
        
        # Melakukan dekripsi dan verifikasi
        decrypted_contents = cipher.decrypt_and_verify(split_contents[2][:-16], split_contents[2][-16:])
        
        # Mengembalikan hasil dekripsi dalam format teks UTF-8
        return decrypted_contents.decode('utf-8', 'ignore')
    except ValueError as e:
        print("Error decrypting file:", str(e))
        return None
    except Exception as e:
        print("Unexpected error:", str(e))
        return None

# Fungsi filter untuk konten mrc

def filter_mrc_content(contents):
    try:
        filtered_contents = "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
        lines = contents.split('\n')
        for line in lines:
            if not line.strip().startswith("</properties>") and not line.strip().startswith("<?xml") and not line.strip().startswith("<!DOCTYPE") and not line.strip().startswith("<properties>"):
                if "<entry" in line and "{" in line and "}" in line:
                    # Exclude lines containing '<entry>' and JSON-like content from filtering
                    filtered_contents += line + "\n"
                elif "<entry" in line:
                    key_value = line.strip().replace("<entry key=\"", "").replace("</entry>", "").replace('"/>', '').split("\">")
                    if len(key_value) > 1:
                        key, value = key_value
                        filtered_contents += f"[#] [{key}]: {value}\n"
                    else:
                        key = key_value[0]
                        filtered_contents += f"[#] [{key}]: ***\n"
                elif "Arquivo de Configuração" not in line:  # Add this condition to exclude lines containing "Arquivo de Configuração"
                    filtered_line = line.replace("<comment/>", "").replace("</entry>", "")  # Remove '<comment/>' and '</entry>'
                    filtered_contents += filtered_line + "\n"
        filtered_contents += "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"           
        return filtered_contents
    except Exception as e:
        return f"Error: {e}"
        
#ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss
##fnnetwork
def decrypt_fnnetwork_file(encrypted_fnnetwork, password):
    try:
        # Memastikan bahwa input adalah objek byte
        if isinstance(encrypted_fnnetwork, str):
            encrypted_fnnetwork = encrypted_fnnetwork.encode('utf-8')

        # Memisahkan konten terenkripsi menjadi bagian-bagian yang sesuai
        split_base64_contents = encrypted_fnnetwork.split(b'.')
        split_contents = list(map(base64.b64decode, split_base64_contents))
        
        # Membangun kunci dekripsi menggunakan PBKDF2
        decryption_key = PBKDF2(password.encode('utf-8'), split_contents[0], hmac_hash_module=SHA256)
        
        # Membuat objek cipher AES dengan mode GCM dan nonce yang sesuai
        cipher = AES.new(decryption_key, AES.MODE_GCM, nonce=split_contents[1])
        
        # Melakukan dekripsi dan verifikasi
        decrypted_contents = cipher.decrypt_and_verify(split_contents[2][:-16], split_contents[2][-16:])
        
        # Mengembalikan hasil dekripsi dalam format teks UTF-8
        return decrypted_contents.decode('utf-8', 'ignore')
    except ValueError as e:
        print("Error decrypting file:", str(e))
        return None
    except Exception as e:
        print("Unexpected error:", str(e))
        return None

# Fungsi filter untuk konten fnnetwork
def filter_fnnetwork_content(contents):
    try:
        filtered_contents = "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
        lines = contents.split('\n')
        for line in lines:
            if line.strip().startswith("<entry"):
                key_value = line.strip().replace("<entry key=\"", "").replace("</entry>", "").replace('"/>', '').split("\">")
                if len(key_value) > 1:
                    key, value = key_value
                    filtered_contents += f"[#] [{key}]: {value}\n"
                else:
                    key = key_value[0]
                    filtered_contents += f"[#] [{key}]: ***\n"
        filtered_contents += "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
        return filtered_contents
    except Exception as e:
        return f"Error: {e}"





#ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss
        
def decrypt_mij_file(encrypted_mij, password):
    try:
        # Memastikan bahwa input adalah objek byte
        if isinstance(encrypted_mij, str):
            encrypted_mij = encrypted_mij.encode('utf-8')

        # Memisahkan konten terenkripsi menjadi bagian-bagian yang sesuai
        split_base64_contents = encrypted_mij.split(b'.')
        split_contents = list(map(base64.b64decode, split_base64_contents))
        
        # Membangun kunci dekripsi menggunakan PBKDF2
        decryption_key = PBKDF2(password.encode('utf-8'), split_contents[0], hmac_hash_module=SHA256)
        
        # Membuat objek cipher AES dengan mode GCM dan nonce yang sesuai
        cipher = AES.new(decryption_key, AES.MODE_GCM, nonce=split_contents[1])
        
        # Melakukan dekripsi dan verifikasi
        decrypted_contents = cipher.decrypt_and_verify(split_contents[2][:-16], split_contents[2][-16:])
        
        # Mengembalikan hasil dekripsi dalam format teks UTF-8
        return decrypted_contents.decode('utf-8', 'ignore')
    except ValueError as e:
        print("Error decrypting file:", str(e))
        return None
    except Exception as e:
        print("Unexpected error:", str(e))
        return None

# Fungsi filter untuk konten mij
def filter_mij_content(contents):
    try:
        filtered_contents = "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
        lines = contents.split('\n')
        for line in lines:
            if not line.strip().startswith("</properties>") and not line.strip().startswith("<?xml") and not line.strip().startswith("<!DOCTYPE") and not line.strip().startswith("<properties>"):
                if "<entry" in line and "{" in line and "}" in line:
                    # Exclude lines containing '<entry>' and JSON-like content from filtering
                    filtered_contents += line + "\n"
                elif "<entry" in line:
                    key_value = line.strip().replace("<entry key=\"", "").replace("</entry>", "").replace('"/>', '').split("\">")
                    if len(key_value) > 1:
                        key, value = key_value
                        filtered_contents += f"[#] [{key}]: {value}\n"
                    else:
                        key = key_value[0]
                        filtered_contents += f"[#] [{key}]: ***\n"
                elif "Arquivo de Configuração" not in line:  # Add this condition to exclude lines containing "Arquivo de Configuração"
                    filtered_line = line.replace("<comment/>", "").replace("</entry>", "")  # Remove '<comment/>' and '</entry>'
                    filtered_contents += filtered_line + "\n"
        filtered_contents += "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"           
        return filtered_contents
    except Exception as e:
        return f"Error: {e}"



#ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss
        
def decrypt_mtl_file(encrypted_mtl, password):
    try:
        # Memastikan bahwa input adalah objek byte
        if isinstance(encrypted_mtl, str):
            encrypted_mtl = encrypted_mtl.encode('utf-8')

        # Memisahkan konten terenkripsi menjadi bagian-bagian yang sesuai
        split_base64_contents = encrypted_mtl.split(b'.')
        split_contents = list(map(base64.b64decode, split_base64_contents))
        
        # Membangun kunci dekripsi menggunakan PBKDF2
        decryption_key = PBKDF2(password.encode('utf-8'), split_contents[0], hmac_hash_module=SHA256)
        
        # Membuat objek cipher AES dengan mode GCM dan nonce yang sesuai
        cipher = AES.new(decryption_key, AES.MODE_GCM, nonce=split_contents[1])
        
        # Melakukan dekripsi dan verifikasi
        decrypted_contents = cipher.decrypt_and_verify(split_contents[2][:-16], split_contents[2][-16:])
        
        # Mengembalikan hasil dekripsi dalam format teks UTF-8
        return decrypted_contents.decode('utf-8', 'ignore')
    except ValueError as e:
        print("Error decrypting file:", str(e))
        return None
    except Exception as e:
        print("Unexpected error:", str(e))
        return None

# Fungsi filter untuk konten mtl
def filter_mtl_content(contents):
    try:
        filtered_contents = "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
        lines = contents.split('\n')
        for line in lines:
            if not line.strip().startswith("</properties>") and not line.strip().startswith("<?xml") and not line.strip().startswith("<!DOCTYPE") and not line.strip().startswith("<properties>"):
                if "<entry" in line and "{" in line and "}" in line:
                    # Exclude lines containing '<entry>' and JSON-like content from filtering
                    filtered_contents += line + "\n"
                elif "<entry" in line:
                    key_value = line.strip().replace("<entry key=\"", "").replace("</entry>", "").replace('"/>', '').split("\">")
                    if len(key_value) > 1:
                        key, value = key_value
                        filtered_contents += f"[#] [{key}]: {value}\n"
                    else:
                        key = key_value[0]
                        filtered_contents += f"[#] [{key}]: ***\n"
                elif "Arquivo de Configuração" not in line:  # Add this condition to exclude lines containing "Arquivo de Configuração"
                    filtered_line = line.replace("<comment/>", "").replace("</entry>", "")  # Remove '<comment/>' and '</entry>'
                    filtered_contents += filtered_line + "\n"
        filtered_contents += "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"           
        return filtered_contents
    except Exception as e:
        return f"Error: {e}"


        
#ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss
#SOCKSREVIVE VOID                                                                      
def decrypt_sksrv_file(encrypted_sksrv, password):
    try:
        # Memastikan bahwa input adalah objek byte
        if isinstance(encrypted_sksrv, str):
            encrypted_sksrv = encrypted_sksrv.encode('utf-8')

        # Memisahkan konten terenkripsi menjadi bagian-bagian yang sesuai
        split_base64_contents = encrypted_sksrv.split(b'.')
        split_contents = list(map(base64.b64decode, split_base64_contents))
        
        # Membangun kunci dekripsi menggunakan PBKDF2
        decryption_key = PBKDF2(password.encode('utf-8'), split_contents[0], hmac_hash_module=SHA256)
        
        # Membuat objek cipher AES dengan mode GCM dan nonce yang sesuai
        cipher = AES.new(decryption_key, AES.MODE_GCM, nonce=split_contents[1])
        
        # Melakukan dekripsi dan verifikasi
        decrypted_contents = cipher.decrypt_and_verify(split_contents[2][:-16], split_contents[2][-16:])
        
        # Mengembalikan hasil dekripsi dalam format teks UTF-8
        return decrypted_contents.decode('utf-8', 'ignore')
    except ValueError as e:
        print("Error decrypting file:", str(e))
        return None
    except Exception as e:
        print("Unexpected error:", str(e))
        return None

# Fungsi filter untuk konten sksrv
def filter_sksrv_content(contents):
    try:
        filtered_contents = "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
        lines = contents.split('\n')
        for line in lines:
            if not line.strip().startswith("</properties>") and not line.strip().startswith("<?xml") and not line.strip().startswith("<!DOCTYPE") and not line.strip().startswith("<properties>"):
                if "<entry" in line and "{" in line and "}" in line:
                    # Exclude lines containing '<entry>' and JSON-like content from filtering
                    filtered_contents += line + "\n"
                elif "<entry" in line:
                    key_value = line.strip().replace("<entry key=\"", "").replace("</entry>", "").replace('"/>', '').split("\">")
                    if len(key_value) > 1:
                        key, value = key_value
                        filtered_contents += f"[#] [{key}]: {value}\n"
                    else:
                        key = key_value[0]
                        filtered_contents += f"[#] [{key}]: ***\n"
                elif "Arquivo de Configuração" not in line:  # Add this condition to exclude lines containing "Arquivo de Configuração"
                    filtered_line = line.replace("<comment/>", "").replace("</entry>", "")  # Remove '<comment/>' and '</entry>'
                    filtered_contents += filtered_line + "\n"
        filtered_contents += "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"           
        return filtered_contents
    except Exception as e:
        return f"Error: {e}"
        
        
#ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss    
##hbd
def decrypt_hbd_file(encrypted_hbd, password):
    try:
        # Memastikan bahwa input adalah objek byte
        if isinstance(encrypted_hbd, str):
            encrypted_hbd = encrypted_hbd.encode('utf-8')

        # Memisahkan konten terenkripsi menjadi bagian-bagian yang sesuai
        split_base64_contents = encrypted_hbd.split(b'.')
        split_contents = list(map(base64.b64decode, split_base64_contents))
        
        # Membangun kunci dekripsi menggunakan PBKDF2
        decryption_key = PBKDF2(password.encode('utf-8'), split_contents[0], hmac_hash_module=SHA256)
        
        # Membuat objek cipher AES dengan mode GCM dan nonce yang sesuai
        cipher = AES.new(decryption_key, AES.MODE_GCM, nonce=split_contents[1])
        
        # Melakukan dekripsi dan verifikasi
        decrypted_contents = cipher.decrypt_and_verify(split_contents[2][:-16], split_contents[2][-16:])
        
        # Mengembalikan hasil dekripsi dalam format teks UTF-8
        return decrypted_contents.decode('utf-8', 'ignore')
    except ValueError as e:
        print("Error decrypting file:", str(e))
        return None
    except Exception as e:
        print("Unexpected error:", str(e))
        return None

# Fungsi filter untuk konten hbd
def filter_hbd_content(contents):
    try:
        filtered_contents = "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
        lines = contents.split('\n')
        for line in lines:
            if line.strip().startswith("<entry"):
                key_value = line.strip().replace("<entry key=\"", "").replace("</entry>", "").replace('"/>', '').split("\">")
                if len(key_value) > 1:
                    key, value = key_value
                    filtered_contents += f"[#] [{key}]: {value}\n"
                else:
                    key = key_value[0]
                    filtered_contents += f"[#] [{key}]: ***\n"
        filtered_contents += "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
        return filtered_contents
    except Exception as e:
        return f"Error: {e}"

        
#ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss    
##hdb
def decrypt_hdb_file(encrypted_hdb, password):
    try:
        # Memastikan bahwa input adalah objek byte
        if isinstance(encrypted_hdb, str):
            encrypted_hdb = encrypted_hdb.encode('utf-8')

        # Memisahkan konten terenkripsi menjadi bagian-bagian yang sesuai
        split_base64_contents = encrypted_hdb.split(b'.')
        split_contents = list(map(base64.b64decode, split_base64_contents))
        
        # Membangun kunci dekripsi menggunakan PBKDF2
        decryption_key = PBKDF2(password.encode('utf-8'), split_contents[0], hmac_hash_module=SHA256)
        
        # Membuat objek cipher AES dengan mode GCM dan nonce yang sesuai
        cipher = AES.new(decryption_key, AES.MODE_GCM, nonce=split_contents[1])
        
        # Melakukan dekripsi dan verifikasi
        decrypted_contents = cipher.decrypt_and_verify(split_contents[2][:-16], split_contents[2][-16:])
        
        # Mengembalikan hasil dekripsi dalam format teks UTF-8
        return decrypted_contents.decode('utf-8', 'ignore')
    except ValueError as e:
        print("Error decrypting file:", str(e))
        return None
    except Exception as e:
        print("Unexpected error:", str(e))
        return None

# Fungsi filter untuk konten hdb
def filter_hdb_content(contents):
    try:
        filtered_contents = "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
        lines = contents.split('\n')
        for line in lines:
            if line.strip().startswith("<entry"):
                key_value = line.strip().replace("<entry key=\"", "").replace("</entry>", "").replace('"/>', '').split("\">")
                if len(key_value) > 1:
                    key, value = key_value
                    filtered_contents += f"[#] [{key}]: {value}\n"
                else:
                    key = key_value[0]
                    filtered_contents += f"[#] [{key}]: ***\n"
        filtered_contents += "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
        return filtered_contents
    except Exception as e:
        return f"Error: {e}"

#ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss    
##uwu
def decrypt_uwu_file(encrypted_uwu, password):
    try:
        # Memastikan bahwa input adalah objek byte
        if isinstance(encrypted_uwu, str):
            encrypted_uwu = encrypted_uwu.encode('utf-8')

        # Memisahkan konten terenkripsi menjadi bagian-bagian yang sesuai
        split_base64_contents = encrypted_uwu.split(b'.')
        split_contents = list(map(base64.b64decode, split_base64_contents))
        
        # Membangun kunci dekripsi menggunakan PBKDF2
        decryption_key = PBKDF2(password.encode('utf-8'), split_contents[0], hmac_hash_module=SHA256)
        
        # Membuat objek cipher AES dengan mode GCM dan nonce yang sesuai
        cipher = AES.new(decryption_key, AES.MODE_GCM, nonce=split_contents[1])
        
        # Melakukan dekripsi dan verifikasi
        decrypted_contents = cipher.decrypt_and_verify(split_contents[2][:-16], split_contents[2][-16:])
        
        # Mengembalikan hasil dekripsi dalam format teks UTF-8
        return decrypted_contents.decode('utf-8', 'ignore')
    except ValueError as e:
        print("Error decrypting file:", str(e))
        return None
    except Exception as e:
        print("Unexpected error:", str(e))
        return None

# Fungsi filter untuk konten uwu
def filter_uwu_content(contents):
    try:
        filtered_contents = "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
        lines = contents.split('\n')
        for line in lines:
            if line.strip().startswith("<entry"):
                key_value = line.strip().replace("<entry key=\"", "").replace("</entry>", "").replace('"/>', '').split("\">")
                if len(key_value) > 1:
                    key, value = key_value
                    filtered_contents += f"[#] [{key}]: {value}\n"
                else:
                    key = key_value[0]
                    filtered_contents += f"[#] [{key}]: ***\n"
        filtered_contents += "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
        return filtered_contents
    except Exception as e:
        return f"Error: {e}"
#ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss
def decrypt_ziv_file(encrypted_ziv, password):
    try:
        # Memastikan bahwa input adalah objek byte
        if isinstance(encrypted_ziv, str):
            encrypted_ziv = encrypted_ziv.encode('utf-8')

        # Memisahkan konten terenkripsi menjadi bagian-bagian yang sesuai
        split_base64_contents = encrypted_ziv.split(b'.')
        split_contents = list(map(base64.b64decode, split_base64_contents))
        
        # Membangun kunci dekripsi menggunakan PBKDF2
        decryption_key = PBKDF2(password.encode('utf-8'), split_contents[0], hmac_hash_module=SHA256)
        
        # Membuat objek cipher AES dengan mode GCM dan nonce yang sesuai
        cipher = AES.new(decryption_key, AES.MODE_GCM, nonce=split_contents[1])
        
        # Melakukan dekripsi dan verifikasi
        decrypted_contents = cipher.decrypt_and_verify(split_contents[2][:-16], split_contents[2][-16:])
        
        # Mengembalikan hasil dekripsi dalam format teks UTF-8
        return decrypted_contents.decode('utf-8', 'ignore')
    except ValueError as e:
        print("Error decrypting file:", str(e))
        return None
    except Exception as e:
        print("Unexpected error:", str(e))
        return None
        
        
# Fungsi filter untuk konten ZIV
def filter_ziv_content(contents):
    try:
        filtered_contents = "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
        lines = contents.split('\n')
        for line in lines:
            if line.strip().startswith("<entry"):
                key_value = line.strip().replace("<entry key=\"", "").replace("</entry>", "").replace('"/>', '').split("\">")
                if len(key_value) > 1:
                    key, value = key_value
                    filtered_contents += f"[#] [{key}]: {value}\n"
                else:
                    key = key_value[0]
                    filtered_contents += f"[#] [{key}]: ***\n"
        filtered_contents += "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
        return filtered_contents
    except Exception as e:
        return f"Error: {e}"

#ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss
             
#================================        
async def get_decrypted_stk(temp_file_path):
    try:
        stk_script_path = 'stk.js'  # Sesuaikan dengan jalur Anda
        node_output = subprocess.check_output(['node', stk_script_path, temp_file_path], stderr=subprocess.STDOUT, timeout=15)
        decrypted_info = node_output.decode() 
        return decrypted_info
    except subprocess.CalledProcessError as e:
        return f"Error: {e.output.decode()}"
    except subprocess.TimeoutExpired:
        return "Proses timeout"
    except FileNotFoundError:
        return "File not found"
    except Exception as e:
        return f"Error: {e}"

#================================
async def get_decrypted_arox(temp_file_path):
    try:
        aro_script_path = 'arox_enc.py'  # Sesuaikan dengan jalur Anda
        node_output = subprocess.check_output(['python3', aro_script_path, temp_file_path], stderr=subprocess.STDOUT, timeout=15)
        decrypted_info = node_output.decode() 
        return decrypted_info
    except subprocess.CalledProcessError as e:
        return f"Error: {e.output.decode()}"
    except subprocess.TimeoutExpired:
        return "Proses timeout"
    except FileNotFoundError:
        return "File not found"
    except Exception as e:
        return f"Error: {e}"        

#================================
async def get_decrypted_sut(temp_file_path):
    try:
        sut_script_path = 'sut.py'  # Sesuaikan dengan jalur Anda
        node_output = subprocess.check_output(['python3', sut_script_path, temp_file_path], stderr=subprocess.STDOUT, timeout=15)
        decrypted_info = node_output.decode() 
        return decrypted_info
    except subprocess.CalledProcessError as e:
        return f"Error: {e.output.decode()}"
    except subprocess.TimeoutExpired:
        return "Proses timeout"
    except FileNotFoundError:
        return "File not found"
    except Exception as e:
        return f"Error: {e}"       
         
#================================
async def get_decrypted_ssh(temp_file_path):
    try:
        sut_script_path = 'ssh.py'  # Sesuaikan dengan jalur Anda
        node_output = subprocess.check_output(['python3', sut_script_path, temp_file_path], stderr=subprocess.STDOUT, timeout=15)
        decrypted_info = node_output.decode() 
        return decrypted_info
    except subprocess.CalledProcessError as e:
        return f"Error: {e.output.decode()}"
    except subprocess.TimeoutExpired:
        return "Proses timeout"
    except FileNotFoundError:
        return "File not found"
    except Exception as e:
        return f"Error: {e}"        

#================================
async def get_decrypted_sks(temp_file_path):
    try:
        stk_script_path = 'sks.js'  # Sesuaikan dengan jalur Anda
        node_output = subprocess.check_output(['node', stk_script_path, temp_file_path], stderr=subprocess.STDOUT, timeout=15)
        decrypted_info = node_output.decode() 
        return decrypted_info
    except subprocess.CalledProcessError as e:
        return f"Error: {e.output.decode()}"
    except subprocess.TimeoutExpired:
        return "Proses timeout"
    except FileNotFoundError:
        return "File not found"
    except Exception as e:
        return f"Error: {e}"

#================================

async def get_decrypted_xtproy(temp_file_path):
    try:
        stk_script_path = 'xtproy.py'  # Sesuaikan dengan jalur Anda
        node_output = subprocess.check_output(['python3', stk_script_path, temp_file_path], stderr=subprocess.STDOUT, timeout=15)
        decrypted_info = node_output.decode() 
        return decrypted_info
    except subprocess.CalledProcessError as e:
        return f"Error: {e.output.decode()}"
    except subprocess.TimeoutExpired:
        return "Proses timeout"
    except FileNotFoundError:
        return "File not found"
    except Exception as e:
        return f"Error: {e}"
#================================

async def get_decrypted_mayatun(temp_file_path):
    try:
        stk_script_path = 'mayatun.py'  # Sesuaikan dengan jalur Anda
        node_output = subprocess.check_output(['python3', stk_script_path, temp_file_path], stderr=subprocess.STDOUT, timeout=15)
        decrypted_info = node_output.decode() 
        return decrypted_info
    except subprocess.CalledProcessError as e:
        return f"Error: {e.output.decode()}"
    except subprocess.TimeoutExpired:
        return "Proses timeout"
    except FileNotFoundError:
        return "File not found"
    except Exception as e:
        return f"Error: {e}"

#================================

async def get_decrypted_rez(temp_file_path):
    try:
        stk_script_path = 'rez.js'  # Sesuaikan dengan jalur Anda
        node_output = subprocess.check_output(['node', stk_script_path, temp_file_path], stderr=subprocess.STDOUT, timeout=15)
        decrypted_info = node_output.decode() 
        return decrypted_info
    except subprocess.CalledProcessError as e:
        return f"Error: {e.output.decode()}"
    except subprocess.TimeoutExpired:
        return "Proses timeout"
    except FileNotFoundError:
        return "File not found"
    except Exception as e:
        return f"Error: {e}"


#================================
async def get_decrypted_hat(temp_file_path):
    try:
        stk_script_path = 'modulhat.js'  # Sesuaikan dengan jalur Anda
        # Menjalankan skrip Node.js sebagai subproses
        node_output = subprocess.check_output(['node', stk_script_path, temp_file_path], stderr=subprocess.STDOUT, timeout=15)
        decrypted_info = node_output.decode() 
        return decrypted_info
    except subprocess.CalledProcessError as e:
        return f"Error: {e.output.decode()}"
    except subprocess.TimeoutExpired:
        return "Proses timeout"
    except FileNotFoundError:
        return "File not found"
    except Exception as e:
        return f"Error: {e}"

#================================

async def get_decrypted_modulepro(temp_file_path):
    try:
        stk_script_path = 'modulepro.js'  # Sesuaikan dengan jalur Anda
        # Menjalankan skrip Node.js sebagai subproses
        node_output = subprocess.check_output(['node', stk_script_path, temp_file_path], stderr=subprocess.STDOUT, timeout=15)
        decrypted_info = node_output.decode() 
        return decrypted_info
    except subprocess.CalledProcessError as e:
        return f"Error: {e.output.decode()}"
    except subprocess.TimeoutExpired:
        return "Proses timeout"
    except FileNotFoundError:
        return "File not found"
    except Exception as e:
        return f"Error: {e}"
        

#================================
#BasePANDA
#================================        
async def get_decrypted_multides(temp_file_path):
    try:
        stk_script_path = 'multides.py'  # Sesuaikan dengan jalur Anda
        # Menjalankan skrip Node.js sebagai subproses
        node_output = subprocess.check_output(['python3', stk_script_path, temp_file_path], stderr=subprocess.STDOUT, timeout=15)
        decrypted_info = node_output.decode() 
        return decrypted_info
    except subprocess.CalledProcessError as e:
        return f"Error: {e.output.decode()}"
    except subprocess.TimeoutExpired:
        return "Proses timeout"
    except FileNotFoundError:
        return "File not found"
    except Exception as e:
        return f"Error: {e}"        

#================================
async def get_decrypted_netmod(temp_file_path):
    try:
        stk_script_path = 'netmod.py'  # Sesuaikan dengan jalur Anda
        # Menjalankan skrip Node.js sebagai subproses
        node_output = subprocess.check_output(['python3', stk_script_path, temp_file_path], stderr=subprocess.STDOUT, timeout=15)
        decrypted_info = node_output.decode() 
        return decrypted_info
    except subprocess.CalledProcessError as e:
        return f"Error: {e.output.decode()}"
    except subprocess.TimeoutExpired:
        return "Proses timeout"
    except FileNotFoundError:
        return "File not found"
    except Exception as e:
        return f"Error: {e}"        
#================================
async def get_decrypted_cloudy(temp_file_path):
    try:
        stk_script_path = 'cloudy.py'  # Sesuaikan dengan jalur Anda
        # Menjalankan skrip Node.js sebagai subproses
        node_output = subprocess.check_output(['python3', stk_script_path, temp_file_path], stderr=subprocess.STDOUT, timeout=15)
        decrypted_info = node_output.decode() 
        return decrypted_info
    except subprocess.CalledProcessError as e:
        return f"Error: {e.output.decode()}"
    except subprocess.TimeoutExpired:
        return "Proses timeout"
    except FileNotFoundError:
        return "File not found"
    except Exception as e:
        return f"Error: {e}"        

#================================
@bot.message_handler(commands=['start'])
async def welcome(message): 
    user_id = message.chat.id  # Mendapatkan ID pengguna
    await bot.send_message(user_id, "hola :v")

# Handler perintah untuk /got hasil decrypt                             
@bot.message_handler(commands=['got'])
async def get_decrypt(message): 
    parsed_params = message.text.replace("/got ", "")
    params = dict(parse_qsl(parsed_params))

    if not params.get("key"): 
        return

    key = DecryptHandler.get_plain_hash(params["key"])
    decrypt_list = await Config.read_config_url()

    if config: 
        unquoted_file_contents = unquote_plus(config["file_contents"])
        file_contents = zlib.decompress(base64.b64decode(unquoted_file_contents))
        file_extension = config["file_extension"]
 
        if file_extension.lower() == '.hat':
            # Simpan file sementara
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
    
            # Mendapatkan informasi terdekripsi menggunakan subproses Node.js
            decrypted_info = await get_decrypted_hat(temp_file_path)
    
            # Buat pesan akhir dan kirimkan
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)
    
            # Hapus file sementara setelah digunakan
            os.remove(temp_file_path)        


        elif file_extension.lower() == '.acm':
            # Simpan file sementara
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
    
            # Mendapatkan informasi terdekripsi menggunakan subproses Node.js
            decrypted_info = await get_decrypted_modulepro(temp_file_path)
    
            # Buat pesan akhir dan kirimkan
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)
    
            # Hapus file sementara setelah digunakan
            os.remove(temp_file_path)                    

        elif file_extension.lower() == '.ePro':
            # Simpan file sementara
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
    
            # Mendapatkan informasi terdekripsi menggunakan subproses Node.js
            decrypted_info = await get_decrypted_modulepro(temp_file_path)
    
            # Buat pesan akhir dan kirimkan
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)
    
            # Hapus file sementara setelah digunakan
            os.remove(temp_file_path)                    

        elif file_extension.lower() == '.zxc':
            # Simpan file sementara
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
    
            # Mendapatkan informasi terdekripsi menggunakan subproses Node.js
            decrypted_info = await get_decrypted_modulepro(temp_file_path)
    
            # Buat pesan akhir dan kirimkan
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)
    
            # Hapus file sementara setelah digunakan
            os.remove(temp_file_path)                    
                                        
        elif file_extension.lower() == '.mina':
            # Dekripsi file .mina
            decrypted_info = decrypt_mina_file(file_contents, mina_password)

            try:
                await bot.send_message(message.chat.id, decrypted_info)
            except Exception as e:
                await bot.send_message(message.chat.id, f"Error: {e}")

        elif file_extension.lower() == '.xscks':
            # Dekripsi file .xscks
            decrypted_info = decrypt_xscks_file(file_contents, xscks_password)

            try:
                await bot.send_message(message.chat.id, decrypted_info)
            except Exception as e:
                await bot.send_message(message.chat.id, f"Error: {e}")


        elif file_extension.lower() == '.ipt':
            # Dekripsi file .ipt
            decrypted_info = decrypt_ipt_file(file_contents, ipt_password)

            try:
                await bot.send_message(message.chat.id, decrypted_info)
            except Exception as e:
                await bot.send_message(message.chat.id, f"Error: {e}")

                
        elif file_extension.lower() == '.stk':
            # Simpan file sementara
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
    
            # Mendapatkan informasi terdekripsi menggunakan subproses Node.js
            decrypted_info = await get_decrypted_stk(temp_file_path)
    
            # Buat pesan akhir dan kirimkan
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)
    
            # Hapus file sementara setelah digunakan
            os.remove(temp_file_path)        


        elif file_extension.lower() == '.aro':
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
            decrypted_info = await get_decrypted_arox(temp_file_path)
    
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)                    
            os.remove(temp_file_path)        

        elif file_extension.lower() == '.sut':
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
            decrypted_info = await get_decrypted_sut(temp_file_path)
    
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)                    
            os.remove(temp_file_path)   

        elif file_extension.lower() == '.ssh':
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
            decrypted_info = await get_decrypted_ssh(temp_file_path)
    
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)                    
            os.remove(temp_file_path)   


        elif file_extension.lower() == '.sks':
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
            decrypted_info = await get_decrypted_sks(temp_file_path)
    
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)                    
            os.remove(temp_file_path)
            
        elif file_extension.lower() == '.xtp':
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
            decrypted_info = await get_decrypted_xtproy(temp_file_path)
    
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)                    
            os.remove(temp_file_path)
            
        elif file_extension.lower() == '.roy':
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
            decrypted_info = await get_decrypted_xtproy(temp_file_path)
    
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)                    
            os.remove(temp_file_path)
            
        elif file_extension.lower() == '.maya':
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
            decrypted_info = await get_decrypted_mayatun(temp_file_path)
    
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)                    
            os.remove(temp_file_path)                  
            
        elif file_extension.lower() == '.rez':
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
            decrypted_info = await get_decrypted_rez(temp_file_path)
    
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)                    
            os.remove(temp_file_path)    
#DES
        elif file_extension.lower() == '.v2i':
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
            decrypted_info = await get_decrypted_multides(temp_file_path)
    
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)                    
            os.remove(temp_file_path)


        elif file_extension.lower() == '.ost':
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
            decrypted_info = await get_decrypted_multides(temp_file_path)
    
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)                    
            os.remove(temp_file_path)


        elif file_extension.lower() == '.agn':
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
            decrypted_info = await get_decrypted_multides(temp_file_path)
    
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)                    
            os.remove(temp_file_path)
            
        elif file_extension.lower() == '.vpc':
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
            decrypted_info = await get_decrypted_multides(temp_file_path)
    
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)                    
            os.remove(temp_file_path)


        elif file_extension.lower() == '.Fɴ':
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
            decrypted_info = await get_decrypted_multides(temp_file_path)
    
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)                    
            os.remove(temp_file_path)


        elif file_extension.lower() == '.cly':
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
            decrypted_info = await get_decrypted_multides(temp_file_path)
    
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)                    
            os.remove(temp_file_path)


        elif file_extension.lower() == '.jvi':
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
            decrypted_info = await get_decrypted_multides(temp_file_path)
    
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)                    
            os.remove(temp_file_path)
            
            
        elif file_extension.lower() == '.Bn':
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
            decrypted_info = await get_decrypted_multides(temp_file_path)
    
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)                    
            os.remove(temp_file_path)
            
            
        elif file_extension.lower() == '.jvc':
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
            decrypted_info = await get_decrypted_multides(temp_file_path)
    
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)                    
            os.remove(temp_file_path)            
            
#DES              
#================================  


        elif file_extension.lower() == '.nm':
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
            decrypted_info = await get_decrypted_netmod(temp_file_path)
    
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)                    
            os.remove(temp_file_path)
            
            
        elif file_extension.lower() == '.cloudy':
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
            decrypted_info = await get_decrypted_cloudy(temp_file_path)
    
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)                    
            os.remove(temp_file_path)
            
        elif file_extension.lower() == '.vpnlite':
            temp_file_path = 'temp_file' + file_extension
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(file_contents)
            decrypted_info = await get_decrypted_cloudy(temp_file_path)
    
            final_text = (
                "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                f"{decrypted_info}"
                "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
            )
            if len(final_text) <= MAX_MESSAGE_LENGTH:
                await bot.reply_to(message, text=f"```{decrypted_info}```", parse_mode="Markdown")
            else:
                await send_message_in_parts(message.chat.id, decrypted_info)                    
            os.remove(temp_file_path)                                    
            
                                    
        elif file_extension.lower() == '.ziv':
            # Dekripsi file .ziv
            decrypted_info = decrypt_ziv_file(file_contents, ziv_password)

            try:
                await bot.send_message(message.chat.id, decrypted_info)
            except Exception as e:
                await bot.send_message(message.chat.id, f"Error: {e}")         
                
        elif file_extension.lower() == '.tnl':
            # Dekripsi file .tnl
            decrypted_info = decrypt_tnl_file(file_contents, tnl_password)

            try:
                await bot.send_message(message.chat.id, decrypted_info)
            except Exception as e:
                await bot.send_message(message.chat.id, f"Error: {e}")         


        elif file_extension.lower() == '.pb':
            # Dekripsi file .ziv
            decrypted_info = decrypt_pb_file(file_contents, pb_password)

            try:
                await bot.send_message(message.chat.id, decrypted_info)
            except Exception as e:
                await bot.send_message(message.chat.id, f"Error: {e}")         
                
        elif file_extension.lower() == '.phc':
            # Dekripsi file .tnl
            decrypted_info = decrypt_phc_file(file_contents, phc_password)

            try:
                await bot.send_message(message.chat.id, decrypted_info)
            except Exception as e:
                await bot.send_message(message.chat.id, f"Error: {e}")
                
        elif file_extension.lower() == '.pcx':
            # Dekripsi file .ziv
            decrypted_info = decrypt_pcx_file(file_contents, pcx_password)

            try:
                await bot.send_message(message.chat.id, decrypted_info)
            except Exception as e:
                await bot.send_message(message.chat.id, f"Error: {e}")         
                
        elif file_extension.lower() == '.mij':
            # Dekripsi file .mij
            decrypted_info = decrypt_mij_file(file_contents, mij_password)

            try:
                await bot.send_message(message.chat.id, decrypted_info)
            except Exception as e:
                await bot.send_message(message.chat.id, f"Error: {e}")         
                
        elif file_extension.lower() == '.mrc':
            # Dekripsi file .mrc
            decrypted_info = decrypt_mrc_file(file_contents, mrc_password)

            try:
                await bot.send_message(message.chat.id, decrypted_info)
            except Exception as e:
                await bot.send_message(message.chat.id, f"Error: {e}")         


        elif file_extension.lower() == '.mtl':
            # Dekripsi file .mij
            decrypted_info = decrypt_mtl_file(file_contents, mtl_password)

            try:
                await bot.send_message(message.chat.id, decrypted_info)
            except Exception as e:
                await bot.send_message(message.chat.id, f"Error: {e}")         
                
        elif file_extension.lower() == '.hbd':
            # Dekripsi file .mrc
            decrypted_info = decrypt_hbd_file(file_contents, hbd_password)

            try:
                await bot.send_message(message.chat.id, decrypted_info)
            except Exception as e:
                await bot.send_message(message.chat.id, f"Error: {e}")
                
        elif file_extension.lower() == '.hdb':
            # Dekripsi file .mij
            decrypted_info = decrypt_hdb_file(file_contents, hdb_password)

            try:
                await bot.send_message(message.chat.id, decrypted_info)
            except Exception as e:
                await bot.send_message(message.chat.id, f"Error: {e}")
                
        elif file_extension.lower() == '.uwu':
            # Dekripsi file .uwu
            decrypted_info = decrypt_uwu_file(file_contents, uwu_password)

            try:
                await bot.send_message(message.chat.id, decrypted_info)
            except Exception as e:
                await bot.send_message(message.chat.id, f"Error: {e}")         
                
        elif file_extension.lower() == '.fnnetwork':
            # Dekripsi file .fnnetwork
            decrypted_info = decrypt_fnnetwork_file(file_contents, fnnetwork_password)

            try:
                await bot.send_message(message.chat.id, decrypted_info)
            except Exception as e:
                await bot.send_message(message.chat.id, f"Error: {e}")         
                                     
                                                                                           
#================================                                             
# Handler pesan untuk dokumen
@bot.message_handler(content_types=['document'])
async def decrypt_document(message): 
    async def create_file_obj(message): 
        file_obj = dict()
        file_obj["file_name"] = message.document.file_name
        file_obj["file_extension"] = Path(file_obj["file_name"]).suffix
        file_obj["file_id"] = message.document.file_id
        file_obj["file_info"] = await bot.get_file(file_obj["file_id"])
        file_obj["downloaded_file"] = await bot.download_file(file_obj["file_info"].file_path)
        return file_obj

    file_obj = await create_file_obj(message)
    

    if file_obj["file_extension"] == ".mina": 
        file_contents = file_obj["downloaded_file"]
        decrypted_info = decrypt_mina_file(file_contents, mina_password)
                 
        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        
        
    elif file_obj["file_extension"] == ".xscks": 
        file_contents = file_obj["downloaded_file"]
        decrypted_info = decrypt_xscks_file(file_contents, xscks_password)
                 
        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)


    elif file_obj["file_extension"] == ".ipt": 
        file_contents = file_obj["downloaded_file"]
        decrypted_info = decrypt_ipt_file(file_contents, ipt_password)
                 
        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
         
        
    elif file_obj["file_extension"] == ".stk": 
        # Simpan file sementara
        temp_file_path = 'temp_file.stk'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])

        # Mendapatkan informasi terdekripsi menggunakan subproses Node.js
        decrypted_info = await get_decrypted_stk(temp_file_path)

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)

        # Hapus file sementara setelah digunakan
        os.remove(temp_file_path)        
        
    elif file_obj["file_extension"] == ".aro": 
        temp_file_path = 'temp_file.aro'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_arox(temp_file_path)
                 
        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path)        

    elif file_obj["file_extension"] == ".sut": 
        temp_file_path = 'temp_file.sut'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_sut(temp_file_path)
                 
        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path)        
        
        
    elif file_obj["file_extension"] == ".ssh": 
        temp_file_path = 'temp_file.ssh'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_ssh(temp_file_path)
                 
        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path)        

    elif file_obj["file_extension"] == ".sks": 
        temp_file_path = 'temp_file.sks'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_sks(temp_file_path)
                 
        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path)        


        
    elif file_obj["file_extension"] == ".xtp": 
        temp_file_path = 'temp_file.xtp'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_xtproy(temp_file_path)

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path)        

    elif file_obj["file_extension"] == ".roy": 
        temp_file_path = 'temp_file.roy'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_xtproy(temp_file_path)

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path)        



    elif file_obj["file_extension"] == ".maya": 
        temp_file_path = 'temp_file.maya'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_mayatun(temp_file_path)

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path)        
        
    elif file_obj["file_extension"] == ".rez": 
        temp_file_path = 'temp_file.rez'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_rez(temp_file_path)

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path)        

    elif file_obj["file_extension"] == ".hat":
        temp_file_path = 'temp_file.hat'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_hat(temp_file_path)

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path)
        
    elif file_obj["file_extension"] == ".acm":
        temp_file_path = 'temp_file.acm'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_modulepro(temp_file_path)

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path)                
                        
    elif file_obj["file_extension"] == ".ePro":
        temp_file_path = 'temp_file.ePro'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_modulepro(temp_file_path)

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path)                


    elif file_obj["file_extension"] == ".zxc":
        temp_file_path = 'temp_file.zxc'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_modulepro(temp_file_path)

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path)                                      

    elif file_obj["file_extension"] == ".v2i":
        temp_file_path = 'temp_file.v2i'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_multides(temp_file_path)

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path)         

    elif file_obj["file_extension"] == ".ost":
        temp_file_path = 'temp_file.ost'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_multides(temp_file_path)

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path)  
                      
    elif file_obj["file_extension"] == ".agn":
        temp_file_path = 'temp_file.agn'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_multides(temp_file_path)

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path)                                                       
    elif file_obj["file_extension"] == ".vpc":
        temp_file_path = 'temp_file.vpc'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_multides(temp_file_path)

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path)         
        
    elif file_obj["file_extension"] == ".Fɴ":
        temp_file_path = 'temp_file.Fɴ'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_multides(temp_file_path)

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path)                        

    elif file_obj["file_extension"] == ".cly":
        temp_file_path = 'temp_file.cly'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_multides(temp_file_path)

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path)                                            


    elif file_obj["file_extension"] == ".jvi":
        temp_file_path = 'temp_file.jvi'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_multides(temp_file_path)

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path)        

    elif file_obj["file_extension"] == ".Bn":
        temp_file_path = 'temp_file.Bn'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_multides(temp_file_path)

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path)  

    elif file_obj["file_extension"] == ".jvc":
        temp_file_path = 'temp_file.jvc'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_multides(temp_file_path)

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path)                                            
        
                              
    elif file_obj["file_extension"] == ".nm":
        temp_file_path = 'temp_file.nm'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_netmod(temp_file_path)

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path)     
        
    elif file_obj["file_extension"] == ".cloudy":
        temp_file_path = 'temp_file.cloudy'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_cloudy(temp_file_path)

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path) 
                                                                                      
    elif file_obj["file_extension"] == ".vpnlite":
        temp_file_path = 'temp_file.vpnlite'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(file_obj["downloaded_file"])
        decrypted_info = await get_decrypted_cloudy(temp_file_path)

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        os.remove(temp_file_path) 


    elif file_obj["file_extension"] == ".ziv": 
        file_contents = file_obj["downloaded_file"]
        decrypted_info = decrypt_ziv_file(file_contents, ziv_password)
    
        # Filter konten yang telah didekripsi
        filtered_info = filter_ziv_content(decrypted_info)
    
        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)


    elif file_obj["file_extension"] == ".tnl": 
        file_contents = file_obj["downloaded_file"]
        decrypted_info = decrypt_tnl_file(file_contents, tnl_password)
    
        # Filter konten yang telah didekripsi
        filtered_info = filter_tnl_content(decrypted_info)
    

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)

    elif file_obj["file_extension"] == ".phc": 
        file_contents = file_obj["downloaded_file"]
        decrypted_info = decrypt_phc_file(file_contents, phc_password)
    
        # Filter konten yang telah didekripsi
        filtered_info = filter_phc_content(decrypted_info)
    

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)


    elif file_obj["file_extension"] == ".pcx": 
        file_contents = file_obj["downloaded_file"]
        decrypted_info = decrypt_pcx_file(file_contents, pcx_password)
    
        # Filter konten yang telah didekripsi
        filtered_info = filter_pcx_content(decrypted_info)
    
        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        
    elif file_obj["file_extension"] == ".pb": 
        file_contents = file_obj["downloaded_file"]
        decrypted_info = decrypt_pb_file(file_contents, pb_password)
    
        # Filter konten yang telah didekripsi
        filtered_info = filter_pb_content(decrypted_info)
    
        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)

    elif file_obj["file_extension"] == ".mrc": 
        file_contents = file_obj["downloaded_file"]
        decrypted_info = decrypt_mrc_file(file_contents, mrc_password)
    
        # Filter konten yang telah didekripsi
        filtered_info = filter_mrc_content(decrypted_info)
    

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)


    elif file_obj["file_extension"] == ".mij": 
        file_contents = file_obj["downloaded_file"]
        decrypted_info = decrypt_mij_file(file_contents, mij_password)
    
        # Filter konten yang telah didekripsi
        filtered_info = filter_mij_content(decrypted_info)
    
        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        
    elif file_obj["file_extension"] == ".fnnetwork": 
        file_contents = file_obj["downloaded_file"]
        decrypted_info = decrypt_fnnetwork_file(file_contents, fnnetwork_password)
    
        # Filter konten yang telah didekripsi
        filtered_info = filter_fnnetwork_content(decrypted_info)
    
        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        
    elif file_obj["file_extension"] == ".uwu": 
        file_contents = file_obj["downloaded_file"]
        decrypted_info = decrypt_uwu_file(file_contents, uwu_password)
    
        # Filter konten yang telah didekripsi
        filtered_info = filter_uwu_content(decrypted_info)
    
        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        
                                       
    elif file_obj["file_extension"] == ".hdb": 
        file_contents = file_obj["downloaded_file"]
        decrypted_info = decrypt_hdb_file(file_contents, hdb_password)
    
        # Filter konten yang telah didekripsi
        filtered_info = filter_hdb_content(decrypted_info)
    
        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
   

    elif file_obj["file_extension"] == ".hbd": 
        file_contents = file_obj["downloaded_file"]
        decrypted_info = decrypt_hbd_file(file_contents, hbd_password)
    
        # Filter konten yang telah didekripsi
        filtered_info = filter_hbd_content(decrypted_info)
    

        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        
    elif file_obj["file_extension"] == ".mtl": 
        file_contents = file_obj["downloaded_file"]
        decrypted_info = decrypt_mtl_file(file_contents, mtl_password)
    
        # Filter konten yang telah didekripsi
        filtered_info = filter_mtl_content(decrypted_info)
    
        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        
                                       
                                                                      
                                                                                                     

#≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠
# Define your Telegram bot and other necessary imports here
# aromod vmess pb
def remove_random_characters(text):
    replacements = {
        ',': '\n',
        '"': '',
        '{': '',
        '}': '',
        'ps:': 'ProfileName: ',
        '\\': '', 
        ':': ' : '
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text
 
def add_marker_to_lines(text, marker="├  𝗗𝗲𝗰𝗼𝗱𝗲 𝗖𝗼𝗻𝗳𝗶𝗴: "):
    lines = text.split('\n')
    filtered_lines = []
    current_marker_lines = []

    for line in lines:
        if marker in line:
            if current_marker_lines:
                filtered_lines.append(''.join(current_marker_lines))
                current_marker_lines = []
            current_marker_lines.append(line)
        else:
            current_marker_lines.append(line)

    if current_marker_lines:
        filtered_lines.append(''.join(current_marker_lines))

    marked_lines = [f'{marker} ```\n{line}```' for line in filtered_lines]
    marked_text = '\n'.join(marked_lines)
    return marked_text


def add_second_marker_to_lines(text, protocol, marker="├  𝗘𝗻𝗰𝗼𝗱𝗲 𝗖𝗼𝗻𝗳𝗶𝗴: ", vmess_marker="├  𝗩𝗺𝗲𝘀𝘀 𝗖𝗼𝗻𝗳𝗶𝗴: "):
    
    if protocol in ["dns", "ssr", "vmess"]:
        # Dekripsi teks jika protokol adalah "dns", "ssr", atau "vmess"
        encoded_line = base64.b64encode(text.encode()).decode()
        if protocol == "vmess":
            marked_line = f'{vmess_marker} ```{protocol}://{encoded_line}```'
        else:
            marked_line = f'{marker} ```{protocol}://{encoded_line}```'
    else:
        marked_line = f'{marker} ```\n{protocol}://{text}```'
    return marked_line
    
def decode_base64(data):
    try:
        decoded_data = base64.b64decode(data)
        return decoded_data.decode('utf-8')
    except Exception as e:
        return str(e)

def decrypt_xraypb(encrypted_text, key, iv):
    cipher = AES.new(key.encode("utf-8"), AES.MODE_CBC, iv.encode("utf-8"))
    decrypted_text = cipher.decrypt(encrypted_text)
    # Apply proper padding removal
    decrypted_text = decrypted_text.rstrip(b"\0")
    return decrypted_text.decode("utf-8")
    

@bot.message_handler(func=lambda message: "vmess://" in message.text or 'nm-' in message.text or  'ar-' in message.text or  'pb-' in message.text or  'zivpn://' in message.text)
async def decode_message(message):
    if 'nm-' in message.text:
        await decrypt_config(message)  # Await decrypt_config coroutine
    elif "ar-" in message.text:
        await armod(message)
    elif "pb-" in message.text:
         await xraypb(message)
    elif "zivpn://" in message.text:
         await handle_enzo(message)
    elif "vmess://" in message.text:
        start_index = message.text.find("vmess://")
        if start_index != -1:
            encoded_data = message.text[start_index + len("vmess://"):]
            decoded_data = decode_base64(encoded_data)
            configdict = json.loads(decoded_data)
            json_formatted = "├ 𝗗𝗲𝗰𝗼𝗱𝗲 𝗖𝗼𝗻𝗳𝗶𝗴: \n```Results\n" + json.dumps(configdict, indent=4) + "```"
        final_text = ("┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                      f"{json_formatted}\n"
                      "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━")
                 
        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        
# ≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠#
#. tolss to decrypt        
async def armod(message):
    encrypted_text_base64 = message.text.strip()
    cle = 'YXJ0dW5uZWw3ODc5Nzg5eA==' 
    pattern = r'^ar-(dns|vless|vmess|trojan|ssr|socks|trojan-go|ssh)://'
    cfg_type = re.match(pattern, encrypted_text_base64)
    try:
        if cfg_type is not None:
            encryption_key = base64.b64decode(cle)

            config_encrypt = encrypted_text_base64[len(cfg_type[0]):]
            encrypted_text = base64.b64decode(config_encrypt)

            # Dekripsi teks
            cipher = AES.new(encryption_key, AES.MODE_ECB)
            decrypt_text = unpad(cipher.decrypt(encrypted_text), AES.block_size)
            decrypt_text = decrypt_text.decode('utf-8')
            
            # Tambahkan marker ke teks yang didekripsi
            formatted_text = add_marker_to_lines(decrypt_text)  # Tambahkan parameter protocol di sini
            formatted_text2 = add_second_marker_to_lines(decrypt_text, cfg_type[1])  # Pass protocol here
            
            # Tambahkan informasi tambahan
            final_text = ("┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                          f"{formatted_text}\n{formatted_text2}\n"
                          "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━")
                 
        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
    except Exception as e:
            print(f"Error: {e}")
         
async def decrypt_config(message):
    encrypted_text_base64 = message.text.strip()
    cle = 'X25ldHN5bmFfbmV0bW9kXw==' 
    pattern = r'^nm-(dns|vless|vmess|trojan|ssr|ss)://'
    cfg_type = re.match(pattern, encrypted_text_base64)
    
    if cfg_type is not None:
        encryption_key = base64.b64decode(cle)

        config_encrypt = encrypted_text_base64[len(cfg_type[0]):]
        encrypted_text = base64.b64decode(config_encrypt)

        # Dekripsi teks
        cipher = AES.new(encryption_key, AES.MODE_ECB)
        decrypt_text = unpad(cipher.decrypt(encrypted_text), AES.block_size)
        decrypt_text = decrypt_text.decode('utf-8')
        
        # Tambahkan marker ke teks yang didekripsi
        formatted_text = add_marker_to_lines(decrypt_text)  # Tambahkan parameter protocol di sini
        formatted_text2 = add_second_marker_to_lines(decrypt_text, cfg_type[1])  # Pass protocol here
        
        # Tambahkan informasi tambahan
        final_text = ("┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                          f"{formatted_text}\n{formatted_text2}\n"
                          "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━")
        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
    


async def xraypb(message):
    # Define the supported protocols
    supported_protocols = ['pb-ssh://', 'pb-vless://', 'pb-trojan://', 'pb-socks://', 'pb-ss://', 'pb-vmess://']
    
    # Extract the configuration encrypted text
    config_encrypt = None
    for protocol in supported_protocols:
        if protocol in message.text:
            config_encrypt = message.text.split(protocol)[1]
            break
    
    # If no supported protocol found, return
    if config_encrypt is None:
        return

    key = "4p+ocx+hGTnbDdHOmzQCjVb9KTTSh+A3"
    iv = "android123456789"

    try:
        if 'pb-vmess://' in message.text:
            ciphertext = b64decode(config_encrypt)
            decrypted_message = decrypt_xraypb(ciphertext, key, iv)
            decrypted_message = b64decode(decrypted_message).decode('utf-8')
        else:
            ciphertext = b64decode(config_encrypt)
            decrypted_message = decrypt_xraypb(ciphertext, key, iv)
        

        pattern = r'^pb-(dns|vless|vmess|trojan|ssr|socks|trojan-go|ssh|ss)://'
        cfg_type = re.match(pattern, message.text)
        
        formatted_text = add_marker_to_lines(decrypted_message)  # Assuming you define this function
        formatted_text2 = add_second_marker_to_lines(decrypted_message, cfg_type[1])  # Assuming you define this function
            
        # Additional information
        final_text = ("┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
                          f"{formatted_text}\n{formatted_text2}\n"
                          "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━")
        
        response = final_text  # Assuming this variable is defined
        
        await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
    except Exception as e:        
        print(f"Error occurred: {str(e)}")

                                                                                         
# ≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠#
     #howdyy
     
def howdy_decode(encrypted_text: str, key: str, init_vector: str) -> str:
    cipher = AES.new(key.encode(), AES.MODE_CBC, init_vector.encode())
    decrypted_bytes = cipher.decrypt(base64.b64decode(encrypted_text))
    decrypted_text = unpad(decrypted_bytes, AES.block_size).decode("utf-8")
    return decrypted_text
    
@bot.message_handler(func=lambda message: True)
async def handle_all_message(message):
    # Cek jika pesan yang diterima mengandung format ar-*
    if 'howdy://' in message.text:
        try:
            # Remove 'howdy://' from the message text
            message_text = message.text.replace('howdy://', '')

            # Mendekripsi data konfigurasi
            encrypted_data = message_text.replace('{"server"', '')
            data = json.loads(base64.b64decode(encrypted_data).decode('utf-8'))
            key = "poiuytrewqas+=~|"  # Ganti dengan kata kunci proses dekripsi
            init_vector = 'r4tgv3b2zcmdW6ZZ'  # Ganti dengan vektor inisialisasi proses dekripsi
            decrypted_server = howdy_decode(data['server'], key, init_vector)
            decrypted_sni = howdy_decode(data['sni'], key, init_vector)
            decrypted_password = data['password']
            decrypted_username = data['username']
            decrypted_port = data['port']
            decrypted_type = data['type']

            # Kirim pesan ke pengguna dengan data konfigurasi yang telah didekripsi
            response = (
                f'┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n'
                f'[#] [Server] = {decrypted_server}'
                f'[#] [SNI] = {decrypted_sni}'
                f'[#] [Port] = {decrypted_port}\n'
                f'[#] [Type] = {decrypted_type}\n'
                f'[#] [Username] = {decrypted_username}'
                f'[#] [Password] = {decrypted_password}'   
                f'━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━'
            )

            await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)
        except Exception as e:
            print(f"Error: {e}")

# ≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠#
#ziv-
def decrypt_zivpn(text):
    encoded_ciphertext = text.replace('zivpn://', '')
    enzo_password = "dTlxdXdscWs4ODFkaTFneGpuMWF1YnkzZmFmdm9tOXQ="
    password = base64.b64decode(enzo_password).decode('utf-8')
    # Assuming AES decryption here, replace with your decryption logic
    decrypted_text = AESCrypt.decrypt(password, encoded_ciphertext)    
    return decrypted_text

def filter_and_markdown(text):
    filtered_contents = "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n"
    lines = text.split('\n')
    for line in lines:
        if line.strip().startswith("<entry"):
            key_value = line.strip().replace("<entry key=\"", "").replace("</entry>", "").replace('"/>', '').split("\">")
            if len(key_value) > 1:
                key, value = key_value
                filtered_contents += f"[#] [{key}]: {value}\n"
            else:
                key = key_value[0]
                filtered_contents += f"[#] [{key}]: ***\n"
    filtered_contents += "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━"
    return filtered_contents

@bot.message_handler(func=lambda message: "zivpn://" in message.text)
async def handle_enzo(message):    
    decrypted_text = decrypt_zivpn(message.text)        
    formatted_message = filter_and_markdown(decrypted_text)
                   
    await bot.send_message(message.chat.id, decrypted_info, reply_to_message_id=message.message_id, disable_web_page_preview=True)




# ≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠#
import asyncio
asyncio.run(bot.polling())

