const fs = require('fs');
const crypto = require('crypto');

// Definisi key
const key = Buffer.from('zbNkuNCGSLivpEuep3BcNA==', 'base64');

// Fungsi untuk melakukan dekripsi AES
function aesDecrypt(data, key) {
    const aesoutp2 = crypto.createDecipheriv("aes-128-ecb", key, null);
    let result = aesoutp2.update(data, "base64", "utf8");
    result += aesoutp2.final("utf-8");
    return result;
}

function xor(plaintext, key = '**rVg7EkL~c2`D[aNn') {
    const keyLength = key.length;
    let cipherAscii = '';
    for (let i = 0; i < plaintext.length; i++) {
        cipherAscii += String.fromCharCode(plaintext.charCodeAt(i) ^ key.charCodeAt(i % keyLength));
    }
    return cipherAscii;
}

// Fungsi untuk mengurai data yang telah di-dekripsi
function parseDecoded(data) {
    var ntah, ntahKeys;
    var error = {};
    try {
        ntah = JSON.parse(data);
        ntahKeys = Object.keys(ntah);
    } catch(error) {}

    // Definisi objek untuk menyimpan informasi terdekripsi
    var decryptedInfo = "┌─[ ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴅᴇᴄ ᴛᴏᴏʟ ғɪɴᴀʟ ᴠᴇʀsɪᴏɴ ]\n└──╼[ Powered by : ᴇʀʀᴏʀ 𝟺𝟶𝟺 ᴛᴇᴀᴍ ]\n\n";

    var connectionMode = [
        "Direct Connection",
        "Custom Payload (TCP)",
        "Custom Host Header (HTTP)",
        "Custom SNI (SSL/TLS)",
        "Imported Config"
    ];

    var connectionMode2 = [
        "SSH",
        "SSL + SSH"
    ];
    var nodeMappings = {
        'xx': 'Random Server, Any Location',
        'us': 'United States, New York',
        'ca': 'Canada, Montréal',
        'de': 'Germany, Frankfurt',
        'uk': 'United Kingdom, London',
        'nl': 'Netherlands, Amsterdam',
        'fr': 'France, Paris',
        'at': 'Vienne, Austria',
        'au': 'Australia, Tasmania',
        'br': 'Brazil, Sao-Paulo',
        'sg': 'Singapore, Simpang',
        'in': 'India, Bangalore',
        'gb': 'Game | EU'
    };
    const layoutFile = fs.readFileSync("nodehat.json");
    const layout = JSON.parse(layoutFile);

    if (!!ntah["configuration"]) {
        error["connectionMethod"] = connectionMode2[ntah["configuration"]["connection_mode"]];
        error["usePayload"] = ntah["configuration"]["using_http_headers"];
        error["payload"] = ntah["configuration"]["http_headers"];
        error["aotServerGroup"] = ntah["configuration"]["server_group_host"];
        error["enableHTTPProxy"] = ntah["configuration"]["using_proxy"];
        error["aotUseHostAsProxy"] = ntah["configuration"]["using_server_hosted_proxy"];
        error["proxyAddress"] = ntah["configuration"]["proxy_host"];
        error["proxyPort"] = ntah["configuration"]["proxy_port"];
        error["aotServerPort"] = ntah["configuration"]["aotServerPort"];
        error["useSSL"] = ntah["configuration"]["using_advssl"];
        error["sniValue"] = ntah["configuration"]["adv_ssl_spoofhost"];
        error["serverPort"] = ntah["configuration"]["adv_ssl_spoofport"];
        error["udpgwPort"] = ntah["configuration"]["vpn_udpgw_port"];
        error["sshServer"] = ntah["configuration"]["server_host"];
        error["sshUser"] = ntah["configuration"]["server_username"];
        error["sshPassword"] = ntah["configuration"]["server_password"];
    }

    if (!!ntah["meta"]) {
        error["note1"] = ntah["meta"]["meta_vendor_msg"];
    }

    if (!!ntah["profile"]) {
        error["connectionMethod"] = connectionMode[ntah["profile"]["connection_mode"]];
        error["payload"] = ntah["profile"]["custom_payload"];
        error["hostHeader"] = ntah["profile"]["custom_host"];
        error["sniValue"] = ntah["profile"]["custom_sni"];
        error["aotRealmHost"] = ntah["profile"]["use_realm_host"] ? ntah["profile"]["realm_host"] : '';
        error["aotRealmHostValue"] = ntah["profile"]["realm_host"];
        error["aotOverrideHost"] = ntah["profile"]["override_primary_host"] ? ntah["profile"]["primary_host"] : '';
        error["aotPrimaryHost"] = ntah["profile"]["primary_host"];
        error["serverPort"] = ntah["profile"]["server_port"] ? ntah["profile"]["server_port"].toString() : '';
        error["aotNode"] = ntah["profile"]["primary_node"];
        error["aotBaseTunnel"] = ntah["profile"]["base_tunnel"];
    }

    if (!!ntah["description"]) {
        error["note1"] = ntah["description"];
    }

    if (!!ntah["profilev4"]) {
        error["connectionMethod"] = connectionMode[ntah["profilev4"]["connection_mode"]];
        error["payload"] = ntah["profilev4"]["custom_payload"];
        error["hostHeader"] = ntah["profilev4"]["custom_host"];
        error["sniValue"] = ntah["profilev4"]["custom_sni"];
        error["aotRealmHost"] = ntah["profilev4"]["use_realm_host"] ? ntah["profilev4"]["realm_host"] : '';
        error["aotRealmHostValue"] = ntah["profilev4"]["realm_host"];
        error["aotOverrideHost"] = ntah["profilev4"]["override_primary_host"] ? ntah["profilev4"]["primary_host"] : '';
        error["aotPrimaryHost"] = ntah["profilev4"]["primary_host"];
        error["serverPort"] = ntah["profilev4"]["server_port"] ? ntah["profilev4"]["server_port"].toString() : '';
        error["aotNode"] = ntah["profilev4"]["primary_node"];
        error["aotBaseTunnel"] = ntah["profilev4"]["base_tunnel"];
    }

    if (!!ntah["descriptionv4"]) {
        error["note1"] = ntah["descriptionv4"];
    }

    if (!!ntah["profilev5"]) {
        error["connectionMethod"] = xor(Buffer.from(ntah["profilev5"]["connection_mode"], 'base64').toString());
        error["payload"] = xor(Buffer.from(ntah["profilev5"]["custom_payload"], 'base64').toString());
        error["hostHeader"] = xor(Buffer.from(ntah["profilev5"]["custom_host"], 'base64').toString());
        error["sniValue"] = xor(Buffer.from(ntah["profilev5"]["custom_sni"], 'base64').toString());
        error["customresolver"] = ntah["profilev5"]["custom_resolver"];
        error["dnsprimaryhost"] = ntah["profilev5"]["dns_primary_host"];
        error["aotRealmHost"] = ntah["profilev5"]["use_realm_host"] ? ntah["profilev5"]["realm_host"] : '';
        error["aotRealmHostValue"] = ntah["profilev5"]["realm_host"];
        error["aotOverrideHost"] = ntah["profilev5"]["override_primary_host"] ? ntah["profilev5"]["primary_host"] : '';
        error["aotPrimaryHost"] = ntah["profilev5"]["primary_host"];
        error["serverPort"] = ntah["profilev5"]["server_port"] ? ntah["profilev5"]["server_port"].toString() : '';
        error["aotNode"] = ntah["profilev5"]["primary_node"];
        error["aotBaseTunnel"] = ntah["profilev5"]["base_tunnel"];
    }

    if (!!ntah["descriptionv5"]) {
        error["note1"] = ntah["descriptionv5"];
    }

    if (!!ntah["protextras"]) {
        try { error["antiSniff"] = ntah["protextras"]["anti_sniff"].toString() } catch(e) {};
        try { error["mobileData"] = ntah["protextras"]["mobile_data"].toString() } catch(e) {};
        try { error["blockRoot"] = ntah["protextras"]["block_root"].toString() } catch(e) {};
        try { error["passwordProtected"] = ntah["protextras"]["password"].toString() } catch(e) {};
        try { error["cryptedPasswordValueMD5"] = ntah["protextras"]["password_value"].toString() } catch(e) {};
        try { error["hwidEnabled"] = ntah["protextras"]["id_lock"].toString() } catch(e) {};
        try { error["cryptedHwidValueMD5"] = ntah["protextras"]["id_lock_value"].toString() } catch(e) {};
        try { error["enableExpire"] = ntah["protextras"]["expiry"].toString() } catch(e) {};
        try { error["expireDate"] = new Date(ntah["protextras"]["expiry_value"]).toUTCString() } catch(e) {};
    }
    
    if (!!error["aotNode"] && nodeMappings[error["aotNode"]]) {
        error["aotNode"] = nodeMappings[error["aotNode"]];
    }
    
    // Menyusun informasi terdekripsi sesuai dengan format yang diinginkan
    Object.keys(layout).forEach(key => {
        if (ntah[key]) {
            error[key] = ntah[key];
        }
    });

    // Menambahkan akhir konten
    
    Object.entries(error).forEach(([key, value]) => {
        decryptedInfo += `[#] ${layout[key]}${value}\n`;
    });

    // Mengembalikan informasi terdekripsi
    return decryptedInfo;
}

function decryptStage(data) {
    var complete = false;
    var response = {};
    response["content"] = '';    

    // Tahap dekripsi
    try {
        const decryptedData = aesDecrypt(data, key);
        if (decryptedData.indexOf("{\"") !== -1) {
            complete = true;
            response["content"] = parseDecoded(decryptedData);
        }
    } catch (error) {
        console.error(error);
    }
     
    response["content"] += "━━━━━━━━━━━━━━━━━━\n[#] GROUPS: [ZETE](https://t.me/ZETEE2023) | [ZETE](https://t.me/OhMyDec) | [ZETE](https://t.me/ViktorianEmpire) | [JINXED](https://t.me/DecryptConfigFile) | [WannKamikaze](https://t.me/KukaSniff) | [Eritsu](https://t.me/Everest72) | [Milan](https://t.me/vpn_injectorid) | [ZEEN](https://t.me/sniffvpnzZ) | [Dans](https://t.me/Vpn_storeid) | [Araaa](https://t.me/SNIFFVPNtop) | [Rimuru](https://t.me/Rimurustore12) ||\n━━━━━━━━━━━━━━━━━━";

    return response;
}

const args = process.argv.slice(2);

// Pastikan argumen yang diberikan sesuai
if (args.length !== 1) {
    console.log('Penggunaan: node hat.js <nama_file_input>');
    process.exit(1);
}

// Baca file input dari argumen baris perintah
const inputFile = args[0];

// Baca file input
fs.readFile(inputFile, 'utf8', (err, data) => {
    if (err) {
        console.error(`Terjadi kesalahan saat membaca file: ${err}`);
        return;
    }
    
    // Lakukan dekripsi tahap
    const decryptedData = decryptStage(data);

    // Output hasil dekripsi
    console.log(decryptedData.content);
});
