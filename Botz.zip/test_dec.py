import base64
import os
import time
import json
import sys
import zlib
import requests
import asyncio

from urllib.parse import parse_qsl, quote_plus
from bs4 import BeautifulSoup

class Object:
    def __init__(self, dict_obj):
        for key, value in dict_obj.items():
            if isinstance(value, dict):
                setattr(self, key, Object(value))
            else:
                setattr(self, key, value)

class Config: 
    operated = False
    config_file_name = "dec_list.json"
    paster_url = "https://rentry.co"
    paster_edit_id = "xv647rwh"
    edit_code = "ekWXPxdJ"
    session = None

    @staticmethod
    def write_file(json_text) -> None: 
        config_file_name = Config.config_file_name
        io_operation = Config.io_operation

        if not os.path.isfile(config_file_name): 
            file = open(config_file_name, 'w')
            file.write("{}")
            file.close()


        while io_operation(): 
            time.sleep(1)

        with open(config_file_name, "w") as f: 
            f.write(json_text)
            f.close()
    
    @staticmethod
    def open_file() -> dict: 
        config_file_name = Config.config_file_name
        io_operation = Config.io_operation

        if not os.path.isfile(config_file_name): 
            file = open(config_file_name, 'w')
            file.write("{}")
            file.close()

        while io_operation(): 
            time.sleep(1)

        with open(config_file_name, "r") as f: 
            data = f.read()
            f.close()
        
        return json.loads(data)
    
    @staticmethod
    async def write_config_url(json_text) -> bool: 
        await Config.init_session()

        session, paster_url, paster_edit_id, edit_code = Config.session, Config.paster_url, Config.paster_edit_id, Config.edit_code
        full_url = os.path.join(paster_url, paster_edit_id, "edit")

        data = {
            'csrfmiddlewaretoken': session.cookies["csrftoken"],
            'text': json_text,
            'edit_code': edit_code,
        }

        headers = {
            'referer': full_url,
        }
        
        try: 
            Config.operated = True
            res = session.post(full_url, headers=headers, data=data)
            if res.status_code == 200: 
                return True
        except: 
            print("Unable To Write Config Url!")
        finally: 
            Config.operated = False

        return False
        
    @staticmethod
    async def read_config_url() -> dict: 
        await Config.init_session()

        session, paster_url, paster_edit_id, edit_code = Config.session, Config.paster_url, Config.paster_edit_id, Config.edit_code
        full_url = os.path.join(paster_url, paster_edit_id)

        try: 
            Config.operated = True
            res = session.get(full_url)
            if res.status_code == 200: 
                res_html = BeautifulSoup(res.content, "html.parser")
                entry_text = res_html.select_one("div.entry-text")
                return json.loads(entry_text.text)
        except: 
            print("Unable To Read Config Url!")
        finally: 
            Config.operated = False
    
    @staticmethod
    async def init_session(): 
        io_operation = Config.io_operation

        while io_operation(): 
            await asyncio.sleep(1)

        if not Config.session: 
            try: 
                session = requests.Session()
                res = session.get(Config.paster_url)

                if res.status_code == 200: 
                    Config.session = session
                    return True
            except: 
                raise Exception("Error Initialize Session!")
        return False
    
    @staticmethod
    def io_operation(): 
        return Config.operated
    
class DecryptHandler: 
    xor_key = ["안","녕","하","세","요","여","러","분"]

    def __init__(self, msg, file_contents): 
        self.msg_id = msg.message_id
        self.user_id = msg.from_user.id
        self.chat_id = msg.chat.id
        self.plain_hash = f"{self.chat_id}_{self.msg_id}_{self.user_id}"
        self.hash = self.create_hash()
        self.file_contents = file_contents

    def compress_file_contents(self) -> str: 
        return base64.b64encode(zlib.compress(self.file_contents)).decode()
    
    def create_hash(self) -> str: 
        cipher_hash = b""
        for idx, char in enumerate(self.plain_hash): 
            left, right = ord(char), ord(self.xor_key[idx % len(self.xor_key)])
            cipher_hash += chr(left ^ right).encode()

        return base64.b64encode(cipher_hash).decode()

    @staticmethod
    def get_plain_hash(base64_hash) -> str: 
        plain_hash = ""
        xor_key = DecryptHandler.xor_key
        decoded_hash = base64.b64decode(base64_hash).decode()

        for idx, char in enumerate(decoded_hash): 
            left, right = ord(char), ord(xor_key[idx % len(xor_key)])
            plain_hash += chr(left ^ right)
        
        return plain_hash
    
    def verify_hash(self, base64_hash) -> bool: 
        plain_hash = ""
        decoded_hash = base64.b64decode(base64_hash).decode()
        
        for idx, char in enumerate(decoded_hash): 
            left, right = ord(char), ord(self.xor_key[idx % len(self.xor_key)])
            plain_hash += chr(left ^ right)
        
        return plain_hash == self.plain_hash
    
    async def get_decrypt_list(self) -> dict: 
        return await Config.read_config_url()
    
    async def update_decrypt_list(self) -> dict: 
        async def write_to_config(decrypt_list): 
            json_decrypt_list = json.dumps(decrypt_list, indent=2)
            await Config.write_config_url(json_decrypt_list)

        decrypt_list = await self.get_decrypt_list()

        key  = self.plain_hash
        file_contents = self.compress_file_contents()
        expiry_time = time.time() + 1800 # masa aktif nya 30 menit

        if not decrypt_list.get(key): 
            decrypt_list[key] = dict(file_contents=file_contents, expiry_time=expiry_time)
            await write_to_config(decrypt_list)
            return { "result": True, "message": f"{key} Success added to decrypt list!" }
        
        return { "result": False, "message": f"Error!: Request Already Exists For {key}" }

async def main(): 
    msg = Object({
        "message_id": 29,
        "from_user": {
            "id": 5724723483
        },
        "chat": {
            "id": 5724723483
        }
    })

    # print(await Config.read_config_url())
    # handler = DecryptHandler(msg, b"haha")
    print(
        DecryptHandler.get_plain_hash("7JWl64Wk7ZWo7ISI7Jqm7Jec65+b67ay7JW964Wh7ZWq7ISI7Jqg7Jed656z67a17JW864Wi7ZSH7ISN7Jqj7JeZ65+e67a17JWx64Wj7ZWt7ISB")
    )
    # loop = asyncio.get_event_loop()
    
    # for x in range(25): 
    #     task = Config.write_config_url(f"google {x}")
    #     loop.create_task(task)
        
if __name__ == "__main__": 
    asyncio.run(main())