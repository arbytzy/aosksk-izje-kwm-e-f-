import requests

cookies = {
    'AppSession': 'ba29f3cead1fe9e8f807d6af6dbe6991',
    'csrfToken': '28e29dd3d25264a956ddabb4cf01c9405def2dc06373f2bacf951b4937bc6245c054f537496631e77dad36daf04817527fa0c22b5e7c2b0265d07abd958c89be',
}

headers = {
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
}

data = {
    '_method': 'POST',
    '_csrfToken': '28e29dd3d25264a956ddabb4cf01c9405def2dc06373f2bacf951b4937bc6245c054f537496631e77dad36daf04817527fa0c22b5e7c2b0265d07abd958c89be',
    'api': '7b2fe5403500d03a3eee0f366c5ce75e7f50442e',
    'url': 'https://x101.vercel.app/?key=7JW664Wl7ZWq7ISP7Jql7Jee65%2BV67a27JW464Wm7ZSH7ISM7Jqk7JeV656z67a27JW464Wn7ZWv7ISJ7Jqm7JeV65%2Be67a07JW7',
    '_Token[fields]': '943de1c6eb22757d845c4c166e912e4f97b7b0d2%3A',
    '_Token[unlocked]': 'adcopy_challenge%7Cadcopy_response%7Cg-recaptcha-response%7Ch-captcha-response',
}

params = {
    "api": "7b2fe5403500d03a3eee0f366c5ce75e7f50442e",
    "url": "https://x101.vercel.app/?key=7JW664Wl7ZWq7ISP7Jql7Jee65%2BV67a27JW464Wm7ZSH7ISM7Jqk7JeV656z67a27JW464Wn7ZWv7ISJ7Jqm7JeV65%2Be67a07JW7"
}
response = requests.post(
    'https://bicolink.com/st',
    params=params,
    cookies=cookies,
    headers=headers,
    data=data,
)

print(response.history[1].url)